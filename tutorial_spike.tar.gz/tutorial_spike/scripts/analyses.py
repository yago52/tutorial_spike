import matplotlib.ticker as mticker
import seaborn as sns
import pandas as pd
from prody import *
from numpy import *
from matplotlib import * 
from pylab import *
import matplotlib.pyplot as plt
import warnings #hide warnings
import pickle
warnings.filterwarnings('ignore') #hide warnings
pd.set_option('display.max_rows', None) # mostrar toda a tabela


spike = parsePDB('6vxx', chain = 'A', subset = 'ca')

data = pd.read_csv('./files/cov3d/data.csv', index_col = 0)
ensemble = loadEnsemble('./ensemble/ensemble.ens.npz')
#data_cov2 = data[(data.Virus == 'SARS-CoV-2')]
#data_cov2 = data_cov.reset_index(drop=True)

pdb_ids = ['6vxx','9crc','7whb','7sxu','7swx','7tf2','7kqe','8v0r','7yc5','7kea','7l2f','6vyb','8cy9','7u0p','8hri','8zc2', '8i9d','7dk6','8h01','7v7j','7yeg']

data = data[data['PDB'].isin(pdb_ids)]
data = data.reset_index(drop=True)

data_antibody = pd.read_csv('./files/cov3d/data_antibody.tsv', sep='\t', names=['PDB', 'chain','antibodyandclass','singlecode','chain_y','gene','family','species'])
data_antibody = data_antibody[data_antibody['PDB'].isin(pdb_ids)]
data_antibody = data_antibody.reset_index(drop=True)

data_receptor = pd.read_csv('./files/cov3d/data_receptor.tsv', sep='\t', names=['PDB','chain','receptor'])
data_receptor = data_receptor[data_receptor['PDB'].isin(pdb_ids)]
data_receptor = data_receptor.reset_index(drop=True)


# # classificação aberta e fechada
ensemble_proj_pcs = calcProjection(ensemble, pca[:2])
ensemble_proj_pc1 = calcProjection(ensemble, pca[0])
ensemble_proj_pc2 = calcProjection(ensemble, pca[1])

pdbid_ensemble = ensemble.getLabels()
pdbid_ensemble_replace_ca = [s.replace("_ca", "") for s in pdbid_ensemble] #retirar _ca
pdbid_ensemble_underline = [s.replace("_", "") for s in pdbid_ensemble_replace_ca] #retirar _
pdbid_ensemble_slice = array([w[:-1] for w in pdbid_ensemble_underline]) #lista com strings menos o último caracter 
chain_slice = array([w[4:] for w in pdbid_ensemble_underline]) #lista com strings menos os 4 primeiros caracteres
pdbid_reshape = pdbid_ensemble_slice.reshape(-1,1) 
chain_reshape = chain_slice.reshape(-1,1)

data_pc_anm = np.concatenate((pdbid_reshape, chain_reshape, ensemble_proj_pcs),axis=1)

df = pd.DataFrame(data_pc_anm, columns = ['pdbid','chain','proj_pc1','proj_pc2']).astype({"pdbid": str,'chain':str, "proj_pc1": float,'proj_pc2':float})

conditions = [(df['proj_pc1'] <= 5), (df['proj_pc1'] > 5)]
values = ['closed', 'open']
df['conformation'] = select(conditions,values)
multi_total = df.set_index(['pdbid','chain'])

## calculating number of contacts (heavy atoms within 4 angstrom) - receptors (heavy atoms)

chains = []
pdb = []
pdbid_ensemble_lig_receptor = []
cadeia_ligante = []
lig_chain = []
lig_name = []
lig_res = []
counts_receptor= []

data_receptor['Counts'] = data_receptor.PDB.map(data_receptor.PDB.value_counts()) #qtd de ligantes por pdb
data_receptor_new = data_receptor.drop_duplicates(subset='PDB')
data_receptor_new = data_receptor_new.reset_index(drop=True)
pdbid_ensemble_underline = [s.replace("_", "") for s in pdbid_ensemble] #retirar _
for n in range(len(data_receptor['PDB'].values.tolist())):
    pdb.append(data_receptor['PDB'].values[n])
    for pdbid in pdbid_ensemble_underline:
        if (pdb[n] == pdbid[0:4]):
            pdbid_ensemble_lig_receptor.append(pdbid[0:4])
            lig_name.append(data_receptor['receptor'].values[n])
            chains.append(pdbid[4:5])
            getpdb = parsePDB(pdbid[0:4])
            cadeia_getpdb = getpdb.select('chain ' + pdbid[4:5]+' and not water and noh')
            cadeia_ligante.append(data_receptor['chain'].values[n])
            ligante = getpdb.select('chain ' + data_receptor['chain'].values[n]+' and not water and noh')
            counts_receptor.append(data_receptor_new[data_receptor_new['PDB'] == pdbid[0:4]]['Counts'].values[0]) 
            protein_contacts = Contacts(cadeia_getpdb)
            contacts = protein_contacts.select(4, ligante)
            if contacts == None:
                lig_chain.append(0)
                lig_res.append(0)
            else:
                lig_chain.append(contacts.numAtoms())
                lig_res.append(list(np.unique(contacts.getResnums())))

'''
#save pickle
f = open('store_receptor.pckl', 'wb')
pickle.dump([chains,pdb,pdbid_ensemble_lig_receptor,
             cadeia_ligante,lig_chain,lig_name,
             lig_res,counts_receptor], f)
f.close()


#load pickle
f = open('store_receptor.pckl', 'rb')

(chains,pdb,pdbid_ensemble_lig_receptor,
 cadeia_ligante,lig_chain,lig_name,
 lig_res,counts_receptor) = pickle.load(f)

f.close()
'''


# Residues in contact with receṕtors
lig_total_2 = []

for i in lig_res:
    if (i != 0):
        for j in i:
            lig_total_2.append(j)

dado_contatos = {'pdbid': pdbid_ensemble_lig_receptor, 'chain': chains, 'contact': lig_chain, 'ligand_chain': cadeia_ligante, 'ligand_name': lig_name, 'ligand_res': lig_res,'counts':counts_receptor}
data_contacts = pd.DataFrame(dado_contatos)
sorted_data_contacts = data_contacts.sort_values(by=['pdbid','chain'])
multi_contacts = sorted_data_contacts.set_index(['pdbid','chain']) #multindex baseado nas colunas

multi_contacts['total_contact_chain'] = multi_contacts.groupby(level = [0,1]).contact.transform('sum')
multi_contacts['type'] = 'receptor'


contacts_ace2 = sorted_data_contacts.loc[sorted_data_contacts['ligand_name'].str.contains('ngiotensin', na = False)]
multi_contacts_ace2 = contacts_ace2.set_index(['pdbid','chain'])
multi_contacts_ace2['total_contact_chain'] = multi_contacts_ace2.groupby(level = [0,1]).contact.transform('sum')

# # anticorpos
chains = []
pdb = []
pdbid_ensemble_lig_anti = []
cadeia_ligante = []
lig_chain = []
lig_name = []
lig_code = []
lig_res = []
counts_anti= []

data_antibody['Counts'] = data_antibody.PDB.map(data_antibody.PDB.value_counts())
data_antibody_new = data_antibody.drop_duplicates(subset='PDB')
data_antibody_new = data_antibody_new.reset_index(drop=True)
for n in range(len(data_antibody['PDB'].values.tolist())):
    pdb.append(data_antibody['PDB'].values[n])
    for pdbid in pdbid_ensemble_underline:
        if (pdb[n] == pdbid[0:4]):
            pdbid_ensemble_lig_anti.append(pdbid[0:4])
            lig_name.append(data_antibody['antibodyandclass'].values[n])
            chains.append(pdbid[4:5])
            getpdb = parsePDB(pdbid[0:4])
            cadeia_getpdb = getpdb.select('chain ' + pdbid[4:5]+ ' and not water and noh')
            cadeia_ligante.append(data_antibody['chain'].values[n])
            lig_code.append(data_antibody['singlecode'].values[n])
            ligante = getpdb.select('chain ' + data_antibody['chain'].values[n]+ ' and not water and noh')
            counts_anti.append(data_antibody_new[data_antibody_new['PDB'] == pdbid[0:4]]['Counts'].values[0])
            protein_contacts = Contacts(cadeia_getpdb)
            contacts = protein_contacts.select(4, ligante)
            if contacts == None:
                lig_chain.append(0)
                lig_res.append(0)
            else:
                lig_chain.append(contacts.numAtoms())
                lig_res.append(list(np.unique(contacts.getResnums())))

'''               
#save pickle
f = open('store_anti.pckl', 'wb')
pickle.dump([chains,pdb,pdbid_ensemble_lig_anti,
             cadeia_ligante,lig_chain,lig_name,
             lig_code,lig_res,counts_anti], f)
f.close()

#load pickle
f = open('store_anti.pckl', 'rb')

(chains,pdb,pdbid_ensemble_lig_anti,
 cadeia_ligante,lig_chain,lig_name,lig_code,
 lig_res,counts_anti) = pickle.load(f)

f.close()
'''
                
lig_total = []

for i in lig_res:
    if (i != 0):
        for j in i:
            lig_total.append(j)
    
dado_contatos = {'pdbid': pdbid_ensemble_lig_anti, 'chain': chains, 'contact': lig_chain, 'ligand_chain': cadeia_ligante, 'ligand_name': lig_name,'ligand_code': lig_code, 'counts': counts_anti}
data_contacts = pd.DataFrame(dado_contatos)
sorted_data_contacts_anti = data_contacts.sort_values(by=['pdbid','chain'])
multi_contacts_anti = sorted_data_contacts_anti.set_index(['pdbid','chain']) #multindex baseado nas colunas
multi_contacts_anti['total_contact_chain'] = multi_contacts_anti.groupby(level = [0,1]).contact.transform('sum')
multi_contacts_anti['type'] = 'antibody'


multi_dados_rec_anti = pd.concat([multi_contacts,multi_contacts_anti])
multi_dados_relevantes = multi_total.merge(multi_dados_rec_anti, left_index = True, right_index = True, how='outer')
multi_dados_relevantes['contact'] = multi_dados_relevantes['contact'].fillna(0.0)
multi_dados_relevantes['total_contact_chain'] = multi_dados_relevantes['total_contact_chain'].fillna(0.0)

# 
# Grouped MultiIndex DataFrame
grouped = multi_total.groupby('pdbid')

# Process each group directly
result = []
for name, group in grouped:
    if len(group) > 3:
        first_three = group.iloc[:3]
        
        remaining = group.iloc[3:].copy()
        remaining.index = pd.MultiIndex.from_tuples(
            [(name + '_', chain) for _, chain in remaining.index],
            names=['pdbid', 'chain']
        )

        result.append(pd.concat([first_three, remaining]))
    else:
        result.append(group)

# Combine all parts back together
multi_total_trimer = pd.concat(result)

multi_total_group = multi_total_trimer.groupby(level=[0]).size().to_list()
count_spike = []
for i in multi_total_group:
    for j in range(i):
        count_spike.append(i)
#
multi_total_trimer['count_spike'] = count_spike
multi_total_trimer = multi_total_trimer[multi_total_trimer.count_spike == 3]

multi_total['count_spike'] = count_spike        
multi_total_new = multi_total.reindex(multi_dados_relevantes.index)
multi_dados_relevantes['count_mon_spike']= multi_total_new['count_spike'].to_list()
multi_dados_relevantes['type'] = multi_dados_relevantes['type'].fillna('apo')
multi_dados_relevantes.loc[multi_dados_relevantes['ligand_name'].str.contains('ngiotensin', na = False), 'type'] = 'receptor(ACE2)' 

#classificação por monômero
apo_chain = multi_dados_relevantes[multi_dados_relevantes.total_contact_chain == 0]
anti_chain = multi_dados_relevantes[(multi_dados_relevantes.type == 'antibody')&(multi_dados_relevantes.contact > 0)]
receptor_chain = multi_dados_relevantes[(multi_dados_relevantes.type == 'receptor')&(multi_dados_relevantes.contact > 0)]
ace2_chain = multi_dados_relevantes[(multi_dados_relevantes.type == 'receptor(ACE2)')&(multi_dados_relevantes.contact > 0)]

apo_chain_final = apo_chain.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])
anti_chain_final = anti_chain.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])
receptor_chain_final = receptor_chain.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])
ace2_chain_final = ace2_chain.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])

# # Calculo qual residuo 614
atoms = []


for j in pdbid_ensemble_underline:
    getpdb = parsePDB(j[:4])
    if (getpdb[j[4],614]) is None:
        atoms.append('None')
    else:
        atoms.append(list(set(getpdb[j[4],614].getResnames()))[0])

'''
#save resdiues        
f = open('store_residue.pckl', 'wb')
pickle.dump(atoms, f)
f.close()

#load pickle
f = open('store_residue.pckl', 'rb')

(atoms) = pickle.load(f)

f.close()
'''

#######################
dados_mutante = {'pdbid': pdbid_ensemble_underline ,'resid_614': atoms}
df_mutate = pd.DataFrame(dados_mutante)
df_mutate['pdbid'] = [x[:4] for x in df_mutate['pdbid']]
df_mutate = df_mutate.drop_duplicates(subset = "pdbid")
df_mutate['conformation'] = 'closed'
df_mutate['many_rbd_open'] = 0
df_mutate['ligand'] = 'without'
df_mutate = df_mutate.sort_values(by='pdbid').reset_index(drop=True)

# in case of not recognized residues
df_mutate.loc[df_mutate['pdbid'] == '7v7j', 'resid_614'] = 'GLY'
df_mutate.loc[df_mutate['pdbid'] == '7u0p', 'resid_614'] = 'ASP'

pdb_orig = data.PDB.to_list()
pdb_mut = df_mutate.pdbid.to_list()
variant = []
for j in pdb_mut:
    for i in pdb_orig:
        if (i == j):
            variant.append(data[data.PDB == i].values[0][2])
            
df_mutate['Variant'] = variant

df_mutate[(df_mutate.resid_614 == 'None')]


# variantes total

open_rbd = []
lista_index_pdb = []
lista_index_pdb = multi_dados_relevantes.index.get_level_values(0).tolist()
for i in range(len(multi_dados_relevantes)):
    if (multi_dados_relevantes['conformation'].values[i] == 'open'):
        open_rbd.append(lista_index_pdb[i])
open_rbd = set(open_rbd)

for i in open_rbd:
    df_mutate.loc[df_mutate['pdbid'] == i, 'conformation'] = 'open'
    

count_conf = multi_total_trimer.groupby([multi_total_trimer.index.get_level_values(0),'conformation']).size()
new_count_conf = count_conf.to_frame(name = 'count').reset_index()
new_count_conf_open = new_count_conf[new_count_conf.conformation == 'open'].reset_index(drop=True)

count_conf = multi_total.groupby([multi_total.index.get_level_values(0),'conformation']).size()
new_count_conf = count_conf.to_frame(name = 'count').reset_index()
new_count_conf_open = new_count_conf[new_count_conf.conformation == 'open'].reset_index(drop=True)

for i in (df_mutate.pdbid.values.tolist()):
    if (i not in (new_count_conf_open.pdbid.values.tolist())):
        if (i not in (new_count_conf_open.pdbid.values.tolist())):
            df_mutate.loc[(df_mutate['pdbid'] == i), 'many_rbd_open'] = 0
        else:
            df_mutate.loc[(df_mutate['pdbid'] == i), 'many_rbd_open'] = new_count_conf_open.loc[new_count_conf_open['pdbid'] == i,'count'].values[0]
    else:
        df_mutate.loc[(df_mutate['pdbid'] == i), 'many_rbd_open'] = new_count_conf_open.loc[new_count_conf_open['pdbid'] == i,'count'].values[0]


for i in (df_mutate.pdbid.values.tolist()):
    if (i in (sorted_data_contacts.pdbid.values.tolist())):
        df_mutate.loc[(df_mutate['pdbid'] == i), 'ligand'] = 'receptor'
    elif (i in (sorted_data_contacts_anti.pdbid.values.tolist())):
        df_mutate.loc[(df_mutate['pdbid'] == i), 'ligand'] = 'antibody'
    
    if (i in (contacts_ace2.pdbid.values.tolist())):
        df_mutate.loc[(df_mutate['pdbid'] == i), 'ligand'] = 'receptor(ACE2)'

                
#add rows from pdbs with two spike trimers

#define specific PDB IDs to add - with underline
pdbs_to_copy = []
for i in multi_total_trimer.index.get_level_values(0).to_list():
    if "_" in i:
        pdbs_to_copy.append(i)
pdbs_to_copy = list(unique(pdbs_to_copy))

# Define specific PDB IDs to add - without underline to copy rows in original dataframe
pdbs_to_copy_w = []
for i in pdbs_to_copy:
    pdbs_to_copy_w.append(i[:4])

# Select only the rows in a new dataframe that match the specified PDB IDs - without underline
df_selected_rows = df_mutate[df_mutate['pdbid'].isin(pdbs_to_copy_w)]

# add underline to these rows 
df_selected_rows['pdbid'] = pdbs_to_copy

# Concat the two dataframes
df_mutate = pd.concat([df_mutate, df_selected_rows], ignore_index=True)


# create df_mutate trimers only
list_trimers = multi_total_trimer.index.to_list()

list_pdb_trimers = []
for pdb,chain in list_trimers:
    list_pdb_trimers.append(pdb)

uni_list_pdb_trimers = list(unique(list_pdb_trimers))

df_mutate_trimers = df_mutate[df_mutate["pdbid"].isin(uni_list_pdb_trimers)]

#%% dados para rmsf

resnum = spike.getResnums()
M=0
sf1_pc = 0
rmsf1_pc = 0 
sf2_pc = 0
rmsf2_pc = 0 
sf3_pc = 0
rmsf3_pc = 0 

sf1 = 0
rmsf1 = 0 
sf2 = 0
rmsf2 = 0 
sf3 = 0
rmsf3 = 0 
sf4 = 0
rmsf4 = 0 
sf5 = 0
rmsf5 = 0 

'''''

formula
rmsf = sqrt((1 /M) * sf)

'''''
#PC1
sf1_pc = calcSqFlucts(pca[0])
M = 972 * 12 
rmsf1_pc = sqrt((1 /M) * sf1_pc) 



#PC2
sf2_pc = calcSqFlucts(pca[1])
M = 972 * 12 
rmsf2_pc = sqrt((1 /M) * sf2_pc) 


#PC3
sf3_pc = calcSqFlucts(pca[2])
M = 972 * 12 
rmsf3_pc = sqrt((1 /M) * sf3_pc) 

#modo1
sf1 = calcSqFlucts(anm[0])
M = 972 * 12 
rmsf1 = sqrt((1 /M) * sf1) 



#modo2
sf2 = calcSqFlucts(anm[1])
M = 972 * 12 
rmsf2 = sqrt((1 /M) * sf2) 


#modo3
sf3 = calcSqFlucts(anm[2])
M = 972 * 12 
rmsf3 = sqrt((1 /M) * sf3) 


#%% distance ntd rbd
ntd_lista=[]
rbd_lista=[]
lista_id = ensemble.getLabels() 

ensemble_pdb = parsePDB('./ensemble/ensemble.pdb')
for i in range(len(ensemble.getLabels())):
    #dados
    ntd = ensemble_pdb.getCoordsets(i)[0:216] #27:303
    rbd = ensemble_pdb.getCoordsets(i)[231:424] #319:541
    #massas
    ntd_massa = np.repeat(12.0107,len(ntd))
    rbd_massa = np.repeat(12.0107,len(rbd))
    #cálculo centro de massa
    ntd_center = calcCenter(ntd,weights=ntd_massa)
    rbd_center = calcCenter(rbd,weights=rbd_massa)
    #listas
    ntd_lista.append(ntd_center)
    rbd_lista.append(rbd_center)
    
distance = []
dict_distance = {}
numconf = ensemble.numConfs()
#numconform = list(range(ensemble.numConfs()))

for i in (range(numconf)):
    dict_distance[lista_id[i]]= calcDistance(ntd_lista[i],rbd_lista[i])
    distance.append(calcDistance(ntd_lista[i],rbd_lista[i]))

# pegar o indice da conformação com distância qualquer
#dict_distance_ord = sorted(zip(dict_distance.values(), dict_distance.keys())) 
df_distance = pd.DataFrame(zip(dict_distance.values(),dict_distance.keys()), columns= ['distance','id'])

#%% radius of gyration

rgyr = []
count = 0

for nomes in ensemble.getLabels():
    rgyr.append(calcGyradius(ensemble[count]))
    count += 1
#%% rmsd do ensemble

rmsd = ensemble.getRMSDs()


# manipulação de erros
apo = multi_dados_relevantes[multi_dados_relevantes.total_contact_chain == 0]
antibody = multi_dados_relevantes[(multi_dados_relevantes.type == 'antibody')&(multi_dados_relevantes.contact > 0)]
receptor = multi_dados_relevantes[(multi_dados_relevantes.type == 'receptor')&(multi_dados_relevantes.contact > 0)]
ace2 = multi_dados_relevantes[(multi_dados_relevantes.type == 'receptor(ACE2)')&(multi_dados_relevantes.contact > 0)]

apo_final = apo.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])
apo_final['type'] = 'apo'
antibody_final = antibody.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])
receptor_final = receptor.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])
ace2_final = ace2.reset_index(level=[0,1]).drop_duplicates(['pdbid','chain'])

##### apagando pdbs problematicos anteriores
#apagar 7dwx de receptores - pois o receptor não faz contato com nenhuma cadeia da spike - Sodium
#apagar 7yeg de antibody - pois apesar de fazer contato, esta não faz com o RBD, além de um maior contato com a ace2

receptor_final = receptor_final.drop(receptor_final[receptor_final['pdbid'] == '7dwx'].index) 
antibody_final = antibody_final.drop(antibody_final[antibody_final['pdbid'] == '7yeg'].index)

# df_total

multi_dados_final = pd.concat([apo_final,antibody_final,receptor_final, ace2_final])

data = {'pdb': pdbid_ensemble_underline}
df_total = pd.DataFrame(data)
df_total['conformation'] = df.conformation
df_total['pc1'] = df.proj_pc1
df_total['pc2'] = df.proj_pc2
ligand = []
for i in df_total.pdb:
    for j,h in zip(multi_dados_final.pdbid,multi_dados_final.chain):
        if (i[:5] == j+h):
            ligand.append(multi_dados_final[(multi_dados_final.pdbid == j) & (multi_dados_final.chain == h)].values[0][11])

variant = []
res = []
for i in df_total.pdb:
    for j in df_mutate.pdbid:
        if i[:4] == j:
            variant.append(df_mutate[df_mutate.pdbid == j].values[0][5])        
            res.append(df_mutate[df_mutate.pdbid == j].values[0][1])        

df_total['variant'] = variant
df_total['res'] = res
df_total['ligand'] = ligand
df_total.insert(1, "pdb_label", ensemble.getLabels())

df_total_percentage_res = df_total.res.value_counts(normalize=True).mul(100).round(2).values.tolist()
df_total_percentage_ligand = df_total.ligand.value_counts(normalize=True).mul(100).round(2).values.tolist()
df_total_without_none = df_total[df_total.variant != 'none']
df_total_w_n_without = df_total_without_none[df_total_without_none.ligand == 'apo']
df_total_w_n_ligand = df_total_without_none[df_total_without_none.ligand != 'apo']

df['ligand'] = df_total.ligand.tolist()


### CALCULATING RBD ANGLE 
atoms_405 = []
atoms_620 = [] #in the article is choseen resid 622 but the reference (6vxx) does not have this resid
atoms_991 = []

for j in range(len(ensemble)):
    atoms_405.append(ensemble.getConformation(j).getCoords()[317])
    
    atoms_620.append(ensemble.getConformation(j).getCoords()[502])
    
    atoms_991.append(ensemble.getConformation(j).getCoords()[815])
    
    
def getAngle(coords1, coords2, coords3, radian=False):
    """Returns bond angle in degrees unless ``radian=True``"""
    RAD2DEG = 180 / pi
    v1 = coords1 - coords2
    v2 = coords3 - coords2

    rad = arccos((v1*v2).sum(-1) / ((v1**2).sum(-1) * (v2**2).sum(-1))**0.5)
    if radian:
        return rad
    else:
        return rad * RAD2DEG
    
angle_405_620_991 = []
for i in range(len(ensemble)):
    angle_405_620_991.append(getAngle(atoms_405[i],atoms_620[i],atoms_991[i]))

df_total['angle'] = angle_405_620_991
df_total['distance_ntd_rbd'] = df_distance.distance.to_list()

################################

#distance between NTDs of the trimer

##select pdbs with trimeric structure 
list_trimers = multi_total_trimer.index.to_list()

count = 0
cv1 = []
cv2 = []
cv3 = []
cv4 = []
cv5 = []
cv6 = []

for pdb, ch in list_trimers:
    if count == 0:
        getpdb = parsePDB(pdb[:4],chain = ch,subset='ca')
        chain_0_ntd = getpdb.select('resid 27 to 303').getCoordsets()[0] #27 - 303
        chain_0_rbd = getpdb.select('resid 319 to 437 509 to 541').getCoordsets()[0] #model #319:437 and 509:541
        count += 1
       
    elif count == 1:
        getpdb = parsePDB(pdb[:4],chain = ch,subset='ca')
        chain_1_ntd = getpdb.select('resid 27 to 303').getCoordsets()[0] #27 - 303
        chain_1_rbd = getpdb.select('resid 319 to 437 509 to 541').getCoordsets()[0] #model #319:437 and 509:541
        count += 1
        
    elif count == 2:
        getpdb = parsePDB(pdb[:4],chain = ch,subset='ca')
        chain_2_ntd = getpdb.select('resid 27 to 303').getCoordsets()[0] #27 - 303
        chain_2_rbd = getpdb.select('resid 319 to 437 509 to 541').getCoordsets()[0] #model #319:437 and 509:541
        count = 0
        #massas
        ntd_massa_0 = np.repeat(12.0107,len(chain_0_ntd))
        rbd_massa_0 = np.repeat(12.0107,len(chain_0_rbd))
        ntd_massa_1 = np.repeat(12.0107,len(chain_1_ntd))
        rbd_massa_1 = np.repeat(12.0107,len(chain_1_rbd))
        ntd_massa_2 = np.repeat(12.0107,len(chain_2_ntd))
        rbd_massa_2 = np.repeat(12.0107,len(chain_2_rbd))
        #cálculo centro de massa
        ntd_center_0 = calcCenter(chain_0_ntd,weights=ntd_massa_0)
        rbd_center_0 = calcCenter(chain_0_rbd,weights=rbd_massa_0)
        ntd_center_1 = calcCenter(chain_1_ntd,weights=ntd_massa_1)
        rbd_center_1 = calcCenter(chain_1_rbd,weights=rbd_massa_1)
        ntd_center_2 = calcCenter(chain_2_ntd,weights=ntd_massa_2)
        rbd_center_2 = calcCenter(chain_2_rbd,weights=rbd_massa_2)
        #listas
        cv4.append(calcDistance(ntd_center_0,ntd_center_1))
        cv5.append(calcDistance(ntd_center_1,ntd_center_2))
        cv6.append(calcDistance(ntd_center_2,ntd_center_0))
        
        cv1.append(calcDistance(rbd_center_0,rbd_center_1))
        cv2.append(calcDistance(rbd_center_1,rbd_center_2))
        cv3.append(calcDistance(rbd_center_2,rbd_center_0))

        
'''                
#save pickle
f = open('store_cvs.pckl', 'wb')
pickle.dump([cv1,cv2,cv3,cv4,cv5,cv6], f)
f.close()
#load pickle
f = open('store_cvs.pckl', 'rb')

(cv1,cv2,cv3,cv4,cv5,cv6) = pickle.load(f)

f.close()
'''

##############################
df_mutate_trimers['cv1'] = cv1
df_mutate_trimers['cv2'] = cv2
df_mutate_trimers['cv3'] = cv3
df_mutate_trimers['cv4'] = cv4
df_mutate_trimers['cv5'] = cv5
df_mutate_trimers['cv6'] = cv6

#area rbd
area_rbd = []
perimeter_rbd = []
for i,j,k in zip(cv1,cv2,cv3):
    s = (i+j+k)/2
    area_rbd.append(sqrt(s*(s-i)*(s-j)*(s-k)))

#area ntd
area_ntd = []
perimeter_ntd = []
for l,m,n in zip(cv4,cv5,cv6):
    s = (l+m+n)/2
    area_ntd.append(sqrt(s*(s-l)*(s-m)*(s-n)))
    
df_mutate_trimers['area_rbd'] = area_rbd
df_mutate_trimers['area_ntd'] = area_ntd




