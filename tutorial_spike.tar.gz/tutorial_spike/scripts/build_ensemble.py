from pandas import *
from numpy import *
from prody import *
from os import mkdir #importar comando para criação de diretório
from os.path import isdir #importar comando para verificação de diretório
from os import chdir 

import os
import gzip
import shutil
from Bio.PDB import PDBList, MMCIFParser, PDBIO

def compress_file(input_path, output_path):
    with open(input_path, 'rb') as f_in, gzip.open(output_path, 'wb') as f_out:
        shutil.copyfileobj(f_in, f_out)
    os.remove(input_path)

def convert_cif_to_pdb_gz(cif_path, pdb_gz_path, structure_id):
    parser = MMCIFParser(QUIET=True)
    structure = parser.get_structure(structure_id, cif_path)
    pdb_path = cif_path.replace(".cif", ".pdb")
    io = PDBIO()
    io.set_structure(structure)
    io.save(pdb_path)
    compress_file(pdb_path, pdb_gz_path)
    os.remove(cif_path)  # Optional: remove .cif after conversion

pdb_ids = ['6vxx','9crc','7whb','7sxu','7swx','7tf2','7kqe','8v0r','7yc5','7kea','7l2f','6vyb','8cy9','7u0p','8hri','8zc2', '8i9d','7dk6','8h01','7v7j','7yeg']
cif= []
pdbl = PDBList()
output_dir = "./structures"
os.makedirs(output_dir, exist_ok=True)

for pdb_id in pdb_ids:
    pdb_id_lower = pdb_id.lower()
    print(f"⏳ Attempting download for {pdb_id.upper()}...")

    try:
        # Try to download .pdb file
        original_path = pdbl.retrieve_pdb_file(pdb_id_lower, file_format="pdb", pdir=output_dir, overwrite=True)
        pdb_path = os.path.join(output_dir, f"{pdb_id_lower}.pdb")
        pdb_gz_path = pdb_path + ".gz"
        shutil.move(original_path, pdb_path)
        compress_file(pdb_path, pdb_gz_path)
        print(f"✔️  Saved as {pdb_gz_path}")
    except Exception:
        print(f"⚠️  PDB not available, trying mmCIF for {pdb_id.upper()}...")

        try:
            cif_path = pdbl.retrieve_pdb_file(pdb_id_lower, file_format="mmCif", pdir=output_dir, overwrite=True)
            pdb_gz_path = os.path.join(output_dir, f"{pdb_id_lower}.pdb.gz")
            convert_cif_to_pdb_gz(cif_path, pdb_gz_path, pdb_id_upper := pdb_id.upper())
            print(f"✔️  Converted and saved as {pdb_gz_path}")
        except Exception as e:
            print(f"❌  Failed to get PDB or mmCIF for {pdb_id.upper()}")
            cif.append(pdb_id)

for i in cif:
    cifu = parsePDB('./structures/'+ i +'.cif')
    writePDB('./structures/'+ i +'.pdb.gz',cifu)

##################
#Pegar estruturas#
##################

#criar pasta
pathPDBFolder(output_dir) #usar essa pasta para estruturas

spike = parsePDB('6vxx', chain = 'A', subset = 'ca')


import string
letters_all = list(string.ascii_lowercase)
letters = letters_all[:6]
letters

for i in letters:
    try:
        globals()['pdbs_%s' % i] = parsePDB(pdb_ids, chain = i.upper(), subset = 'ca')
    except:
        pass


###########################
#       Ensemble          #
###########################

   
for i in letters:
    try:
        globals()['ensemble_%s' % i] = buildPDBEnsemble(globals()['pdbs_%s' % i], ref = spike, superpose=True,coverage=50, title= 'chain_'+ i)
    except:
        pass

ensemble = ensemble_a
for i in letters[1:]:
    try:
        ensemble += globals()['ensemble_%s' % i]
    except:
        pass

#######################
#    remove gaps      #
#######################

conf_keep = []
for count,i in enumerate(ensemble.getLabels()):
    if ensemble[count].getSequence().numGaps() <= 97:
        conf_keep.append(i)

ensemble = ensemble[conf_keep]
        
if not isdir('ensemble'): #se diretório não existir
    mkdir('ensemble') #criar diretório

writePDB('./ensemble/ensemble.pdb',ensemble)
saveEnsemble(ensemble, './ensemble/ensemble')

