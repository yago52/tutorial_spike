ntd = which(pdbs.all$resno[1,] >=27 & pdbs.all$resno[1,] <=303)
int1 = which(pdbs.all$resno[1,] >=304 & pdbs.all$resno[1,] <=318)
rbd = which(pdbs.all$resno[1,] >=319 & pdbs.all$resno[1,] <=541)
s1 = which(pdbs.all$resno[1,] >=542 & pdbs.all$resno[1,] <=591)
s2 = which(pdbs.all$resno[1,] >=592 & pdbs.all$resno[1,] <=686)
int2 = which(pdbs.all$resno[1,] >=687 & pdbs.all$resno[1,] <=716)
int3 = which(pdbs.all$resno[1,] >=717 & pdbs.all$resno[1,] <=757)
int4 = which(pdbs.all$resno[1,] >=758 & pdbs.all$resno[1,] <=815)
fp = which(pdbs.all$resno[1,] >=816 & pdbs.all$resno[1,] <=855)
int5 = which(pdbs.all$resno[1,] >=856 & pdbs.all$resno[1,] <=919)
hr1 = which(pdbs.all$resno[1,] >=920 & pdbs.all$resno[1,] <=970)
ch = which(pdbs.all$resno[1,] >=971 & pdbs.all$resno[1,] <=1035)
cterm = which(pdbs.all$resno[1,] >=1036 & pdbs.all$resno[1,] <=1147)

membership = rep(1, 972)
membership[ntd] = 1
membership[int1] = 2
membership[rbd] = 3
membership[s1] = 4
membership[s2] = 5
membership[int2] = 6
membership[int3] = 7
membership[int4] = 8
membership[fp] = 9
membership[int5] = 10
membership[hr1] = 11
membership[ch] = 12
membership[cterm] = 13



