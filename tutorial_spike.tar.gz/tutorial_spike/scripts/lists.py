lista_cadeia_ligado = []
lista_cadeia_ligado_correta = []
ligado = sorted_data_contacts[(sorted_data_contacts.contact > 0)] 
for i in range(len(ligado)):
    lista_cadeia_ligado.append(ligado['pdbid'].values[i] + ligado['chain'].values[i] + '_ca')


for j in lista_cadeia_ligado:
    if j not in ensemble.getLabels():
        lista_cadeia_ligado_correta.append(j[:4]+'_'+j[4:])
    else:
        lista_cadeia_ligado_correta.append(j)

lista_cadeia_ace2 = []
lista_cadeia_ace2_correta = []
ligado_ace2 = contacts_ace2[contacts_ace2.contact > 0]
for i in range(len(ligado_ace2)):
    lista_cadeia_ace2.append(ligado_ace2['pdbid'].values[i] + ligado_ace2['chain'].values[i] + '_ca')

for j in lista_cadeia_ace2:
    if j not in ensemble.getLabels():
        lista_cadeia_ace2_correta.append(j[:4]+'_'+j[4:])
    else:
        lista_cadeia_ace2_correta.append(j)
#%% diferença ace2 e receptors

lista_non_ace2 = list(set(lista_cadeia_ligado_correta) - set(lista_cadeia_ace2_correta))

##### ANTIBODY

lista_cadeia_ligado_anti = []
lista_cadeia_anti_correta = []
ligado_anti = sorted_data_contacts_anti[sorted_data_contacts_anti.contact > 0] 
for i in range(len(ligado_anti)):
    lista_cadeia_ligado_anti.append(ligado_anti['pdbid'].values[i] + ligado_anti['chain'].values[i] + '_ca')

for j in lista_cadeia_ligado_anti:
    if j not in ensemble.getLabels():
        lista_cadeia_anti_correta.append(j[:4]+'_'+j[4:])
    else:
        lista_cadeia_anti_correta.append(j)

# # pegando estruturas sem ligante

lista_ligantes = []
lista_cadeias_nao_ligantes = []
pdb_ensemble = []
lista_ligantes = set(lista_cadeia_ligado_correta) | set(lista_cadeia_anti_correta)
pdb_ensemble  = set(ensemble.getLabels())
lista_cadeias_nao_ligantes = sorted(list(lista_ligantes ^ pdb_ensemble))

lista_pdbs_sem_ligantes = []
lista_teste = []

for i in lista_cadeias_nao_ligantes:
    lista_teste.append(i[:4])
count = 0
for j in lista_teste:
    if (lista_teste.count(j) == 3):
        lista_pdbs_sem_ligantes.append(j)

lista_pdbs_sem_ligantes = list(lista_pdbs_sem_ligantes)
lista_sem_ligante = []
for pdbid in pdb_ensemble:
    for i in lista_pdbs_sem_ligantes:
        if (i == pdbid[0:4]):
            lista_sem_ligante.append(pdbid)       
            
            
#############################################
lista_ligantes = []
lista_cadeias_nao_ligantes = []
pdb_ensemble = []
lista_ligantes = set(lista_cadeia_anti_correta) | set(lista_non_ace2) | set(lista_cadeia_ace2_correta)
pdb_ensemble  = set(ensemble.getLabels())
lista_cadeias_nao_ligantes = sorted(list(lista_ligantes ^ pdb_ensemble))

#############################################
#antibody
lista_cadeia_ligado_anti = []
lista_cadeia_anti_correta = []
ligado_anti = sorted_data_contacts_anti[sorted_data_contacts_anti.contact > 0]
for i in range(len(anti_chain_final)):
    lista_cadeia_ligado_anti.append(anti_chain_final['pdbid'].values[i] + anti_chain_final['chain'].values[i] + '_ca')

for j in lista_cadeia_ligado_anti:
    if j not in ensemble.getLabels():
        lista_cadeia_anti_correta.append(j[:4]+'_'+j[4:])
    else:
        lista_cadeia_anti_correta.append(j)


#receptor
lista_cadeia_ligado = []
lista_cadeia_ligado_correta = []
for i in range(len(receptor_chain_final)):
    lista_cadeia_ligado.append(receptor_chain_final['pdbid'].values[i] + receptor_chain_final['chain'].values[i] + '_ca')


for j in lista_cadeia_ligado:


    if j not in ensemble.getLabels():
        lista_cadeia_ligado_correta.append(j[:4]+'_'+j[4:])
    else:
        lista_cadeia_ligado_correta.append(j)

#ace2
lista_cadeia_ace2 = []
lista_cadeia_ace2_correta = []

for i in range(len(ace2_chain_final)):
    lista_cadeia_ace2.append(ace2_chain_final['pdbid'].values[i] + ace2_chain_final['chain'].values[i] + '_ca')

for j in lista_cadeia_ace2:
    if j not in ensemble.getLabels():
        lista_cadeia_ace2_correta.append(j[:4]+'_'+j[4:])
    else:
        lista_cadeia_ace2_correta.append(j)
        


#apo
lista_cadeia_sem_ligante = []
lista_cadeia_sem_ligante_correta = []

for i in range(len(apo_chain_final)):
    lista_cadeia_sem_ligante.append(apo_chain_final['pdbid'].values[i] + apo_chain_final['chain'].values[i] + '_ca')

for j in lista_cadeia_sem_ligante:
    if j not in ensemble.getLabels():
        lista_cadeia_sem_ligante_correta.append(j[:4]+'_'+j[4:])
    else:
        lista_cadeia_sem_ligante_correta.append(j)


###########################

lista_var = df_mutate.Variant.value_counts().index.to_list()
lista_percentage = df_mutate.Variant.value_counts(normalize=True).mul(100).round(2).values.tolist()
# create lists for all variants
for i in lista_var:
    globals()['lista_%s' % i] = []

# populate each list of variants with their labels of the ensemble
for i in lista_var:
    globals()['df_%s' % i] = df_mutate[df_mutate.Variant == i].pdbid.to_list()
    for j in globals()['df_%s' % i]:
        for h in ensemble.getLabels():
            if (j == h[:4]):
                globals()['lista_%s' % i].append(h)

#############################

#%% variantes sem ligante 

df_mutate_without = df_mutate[df_mutate['ligand'] == 'without']
lista_var_without = df_mutate_without.Variant.value_counts().index.to_list()
lista_percentage_without = df_mutate_without.Variant.value_counts(normalize=True).mul(100).round(2).values.tolist()
for i in lista_var_without:
    globals()['lista_%s_without' % i] = []

for i in lista_var_without:
    globals()['df_%s_without' % i] = df_mutate_without[df_mutate_without.Variant == i].pdbid.to_list()
    for j in globals()['df_%s_without' % i]:
        for h in ensemble.getLabels():
            if (j == h[:4]):
                globals()['lista_%s_without' % i].append(h)
                    
#%% variantes com ligantes

df_mutate_ligand = df_mutate[df_mutate['ligand'] != 'without']
lista_var_ligand = df_mutate_ligand.Variant.value_counts().index.to_list()
lista_percentage_ligand = df_mutate_ligand.Variant.value_counts(normalize=True).mul(100).round(2).values.tolist()
for i in lista_var_ligand:
    globals()['lista_%s_ligand' % i] = []

for i in lista_var_ligand:
    globals()['df_%s_ligand' % i] = df_mutate_ligand[df_mutate_ligand.Variant == i].pdbid.to_list()
    for j in globals()['df_%s_ligand' % i]:
        for h in ensemble.getLabels():
            if (j == h[:4]):
                globals()['lista_%s_ligand' % i].append(h)
###########################################


lista_g = []
lista_d = []
lista_others = []

for i in range(len(df_mutate)):
    if (df_mutate['resid_614'].values[i] == 'GLY'):
        lista_g.append(df_mutate['pdbid'].values[i])
    elif (df_mutate['resid_614'].values[i] == 'ASP'):
        lista_d.append(df_mutate['pdbid'].values[i])
    else:
        lista_others.append(df_mutate['pdbid'].values[i])

lista_g = [s.replace(" ", "") for s in lista_g]
lista_d = [s.replace(" ", "") for s in lista_d]
lista_others = [s.replace(" ", "") for s in lista_others]

# ## dados finais
# 
lista_index = []
lista_index = multi_dados_relevantes.index.tolist()


# ### total
lista_pdbs = []
lista_pc1 = []
lista_pc2 = []
lista_cor = []

for j in lista_index:
    lista_pdbs.append(j[0]+j[1]+'_ca')

for i in range(len(multi_dados_relevantes)):
    lista_pc1.append(multi_dados_relevantes['proj_pc1'].values[i])
    lista_pc2.append(multi_dados_relevantes['proj_pc2'].values[i])
    lista_cor.append(multi_dados_relevantes['total_contact_chain'].values[i])


# ### receptor
df_multi_receptor = multi_dados_relevantes[multi_dados_relevantes.type == 'receptor']
lista_index_receptor = []
lista_index_receptor = multi_dados_relevantes[multi_dados_relevantes.type == 'receptor'].index.values.tolist()
lista_pdbs_receptor = []
lista_pc1_receptor = []
lista_pc2_receptor = []
lista_cor_receptor = []

for j in lista_index_receptor:
    lista_pdbs_receptor.append(j[0]+j[1]+'_ca')
    
for i in range(len(df_multi_receptor)):
    lista_pc1_receptor.append(df_multi_receptor['proj_pc1'].values[i])
    lista_pc2_receptor.append(df_multi_receptor['proj_pc2'].values[i])
    lista_cor_receptor.append(df_multi_receptor['total_contact_chain'].values[i])


# ### ace2
df_multi_ace2 = multi_dados_relevantes[multi_dados_relevantes.type == 'receptor(ACE2)']
lista_index_ace2 = []
lista_index_ace2 = df_multi_ace2.index.values.tolist()
lista_pdbs_ace2 = []
lista_pc1_ace2 = []
lista_pc2_ace2 = []
lista_cor_ace2 = []

for j in lista_index_ace2:
    lista_pdbs_ace2.append(j[0]+j[1]+'_ca')
    
for i in range(len(df_multi_ace2)):
    lista_pc1_ace2.append(df_multi_ace2['proj_pc1'].values[i])
    lista_pc2_ace2.append(df_multi_ace2['proj_pc2'].values[i])
    lista_cor_ace2.append(df_multi_ace2['total_contact_chain'].values[i])


# ### antibody
df_multi_anti = multi_dados_relevantes[multi_dados_relevantes.type == 'antibody']
lista_index_anti = []
lista_index_anti = df_multi_anti.index.values.tolist()
lista_pdbs_anti = []
lista_pc1_anti = []
lista_pc2_anti = []
lista_cor_anti = []

for j in lista_index_anti:
    lista_pdbs_anti.append(j[0]+j[1]+'_ca')
    
for i in range(len(df_multi_anti)):
    lista_pc1_anti.append(df_multi_anti['proj_pc1'].values[i])
    lista_pc2_anti.append(df_multi_anti['proj_pc2'].values[i])
    lista_cor_anti.append(df_multi_anti['total_contact_chain'].values[i])

#####################


# #### grafico de cores de contatos
lista_cor_total = []
for i in range(len(multi_dados_relevantes)):
    lista_cor_total.append(multi_dados_relevantes['total_contact_chain'].values[i])
lista_cor_anti_total = []
for i in range(len(df_multi_anti)):
    lista_cor_anti_total.append(df_multi_anti['contact'].values[i])

#%% domain bar - num

# create atomgroup
dom = AtomGroup('Spike')
coords= array(np.tile([0,0,1],(1273,1)),dtype=float)
dom.setCoords(coords)
res = np.repeat(['CA'],1273)
dom.setResnames(res)
resn = list(range(1,1274))
dom.setResnums(resn)
dom.getResnums().tolist().index(27)

# create selections
dom.setData('domain','NTD')
dom.select('all').setData('domain','')
dom.select('resnum 27 to 304').setData('domain','NTD') #27
dom.select('resnum 319 to 542').setData('domain','RBD')
dom.select('resnum 437 to 508').setData('domain','RBM')
dom.select('resnum 689 to 1147').setData('domain','S2') #1148


#%% domain bar 2 - indices

# create atomgroup
dom2 = AtomGroup('Spike')
coords= array(np.tile([0,0,1],(1273,1)),dtype=float)
dom2.setCoords(coords)
res = np.repeat(['CA'],1273)
dom2.setResnames(res)
resn = list(range(1,1274))
dom2.setResnums(resn)
dom2.getResnums().tolist().index(27)

# create selections
dom2.setData('domain','NTD')
dom2.select('all').setData('domain','')
dom2.select('resid 0 to 216').setData('domain','NTD') #27
dom2.select('resid 231 to 424').setData('domain','RBD')
dom2.select('resid 349 to 390').setData('domain','RBM')
dom2.select('resid 539 to 971').setData('domain','S2')


#%% resid 614 g

lista_pc1_g = []
lista_pc2_g = []

for i in lista_g:
    for j in (set(lista_pdbs)):
        if (i[:4]==j[:4]):
            lista_pc1_g.append(multi_dados_relevantes.loc[(j[:4],j[4]),'proj_pc1'].values[0])
        
            lista_pc2_g.append(multi_dados_relevantes.loc[(j[:4],j[4]),'proj_pc2'].values[0])
       
            
            
#%% resid 614 d

lista_pc1_d = []
lista_pc2_d = []

for i in lista_d:
    for j in (set(lista_pdbs)):
        if (i[:4]==j[:4]):
            lista_pc1_d.append(multi_dados_relevantes.loc[(j[:4],j[4]),'proj_pc1'].values[0])
           
            lista_pc2_d.append(multi_dados_relevantes.loc[(j[:4],j[4]),'proj_pc2'].values[0])
     
          
#%% resid 614 others

lista_pc1_others = []
lista_pc2_others = []

for i in lista_others:
    for j in (set(lista_pdbs)):
        if (i[:4]==j[:4]):
            lista_pc1_others.append(multi_dados_relevantes.loc[(j[:4],j[4]),'proj_pc1'].values[0])
          
            lista_pc2_others.append(multi_dados_relevantes.loc[(j[:4],j[4]),'proj_pc2'].values[0])
           

#%% lista so ace2 - lig_res

sub_ace2 = multi_dados_relevantes.loc[multi_dados_relevantes['type'] == 'receptor(ACE2)', 'ligand_res'].tolist()
lista_res_ace2 = []

for i in sub_ace2:
    if (i != 0):
        for j in i:
            lista_res_ace2.append(j)

#%% lista so receptor - lig_res

sub_receptor = multi_dados_relevantes.loc[multi_dados_relevantes['type'] == 'receptor', 'ligand_res'].tolist()
lista_res_receptor = []

for i in sub_receptor:
    if (i != 0):
        for j in i:
            lista_res_receptor.append(j)
#%% dados para boxplot PC1

#ensemble_lista_cadeia_ligado_correta_proj_pc1 = calcProjection(ensemble[lista_non_ace2], pca[0])
ensemble_lista_cadeia_ace2_proj_pc1 = calcProjection(ensemble[lista_cadeia_ace2_correta], pca[0])
ensemble_lista_cadeia_ligado_anti_proj_pc1 = calcProjection(ensemble[lista_cadeia_anti_correta], pca[0])
ensemble_lista_sem_ligante_proj_pc1 = calcProjection(ensemble[lista_cadeia_sem_ligante_correta], pca[0])
data_box_pc1 = [ensemble_lista_cadeia_ace2_proj_pc1,ensemble_lista_cadeia_ligado_anti_proj_pc1,
        ensemble_lista_sem_ligante_proj_pc1]

#%% dados para boxplot PC2

#ensemble_lista_cadeia_ligado_correta_proj_pc2 = calcProjection(ensemble[lista_cadeia_ligado_correta], pca[1])
ensemble_lista_cadeia_ace2_proj_pc2 = calcProjection(ensemble[lista_cadeia_ace2_correta], pca[1])
ensemble_lista_cadeia_ligado_anti_proj_pc2 = calcProjection(ensemble[lista_cadeia_anti_correta], pca[1])
ensemble_lista_sem_ligante_proj_pc2 = calcProjection(ensemble[lista_cadeia_sem_ligante_correta], pca[1])
data_box_pc2 = [ensemble_lista_sem_ligante_proj_pc2, ensemble_lista_cadeia_ligado_anti_proj_pc2, ensemble_lista_cadeia_ace2_proj_pc2]
######################

# variantes por cadeia

#%% variantes sem ligante 

lista_var_cadeia_apo = df_total_w_n_without.variant.value_counts().index.to_list()
lista_percentage_cadeia_apo = df_total_w_n_without.variant.value_counts(normalize=True).mul(100).round(2).values.tolist()

for i in lista_var_cadeia_apo:
    globals()['lista_%s_cadeia_apo' % i] = df_total_w_n_without[df_total_w_n_without.variant == i].pdb_label.to_list()
                    
#%% variantes com ligantes

lista_var_cadeia_ligand = df_total_w_n_ligand.variant.value_counts().index.to_list()
lista_percentage_cadeia_ligand = df_total_w_n_ligand.variant.value_counts(normalize=True).mul(100).round(2).values.tolist()

for i in lista_var_cadeia_ligand:
    globals()['lista_%s_cadeia_ligand' % i] = df_total_w_n_ligand[df_total_w_n_ligand.variant == i].pdb_label.to_list()
                
#####################