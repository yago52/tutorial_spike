export PATH="/home/harold/LINUXAMD64/bin/catdcd4.0/:$PATH" 

catdcd -o sum_K_ps_rep.dcd -otype dcd -dcd ./rep_?_ca.dcd ./rep_??_ca.dcd ./rep_???_ca.dcd #modify
