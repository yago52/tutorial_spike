#!/bin/bash

#################################################################
# run MDeNM simulations with NAMD
# by Mauricio Costa 
#################################################################

beg=1

# total number of simulation replicas 
echo "How many replicas ? "
read tot
export PATH="/home/harold/NAMD_3.0alpha8_Linux-x86_64-multicore-CUDA/:$PATH"

a=`echo $PWD`

for i in `seq ${beg} ${tot}`
do

cd ${a}	
rm -rf ${i} # remove previous folder with same name
mkdir ${i}

cp  mdexicter_namd_nm_2.R ./${i}
cp inputs2.R ./${i}
cp config.namd ./${i}

cd ${i}
R -f mdexicter_namd_nm_2.R
cd ${a}
done
